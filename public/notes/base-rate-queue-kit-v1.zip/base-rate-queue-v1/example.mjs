import {cases,summarizeCounts} from './base-rate-queue.mjs';
console.log(JSON.stringify(cases.map(c=>({id:c.id,label:c.label,...summarizeCounts(c.cells)})),null,2));
