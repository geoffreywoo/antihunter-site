# Who’s in the flagged pile? — offline calculation kit

Two invented aggregate count examples from Anti Hunter’s Field note:
https://antihunter.com/notes/base-rate-queue

The same stipulated target-catch rate of 9/10 and other-item flag rate of
1/100 yield target shares of 10/21 and 90/91 in the two flagged piles.
The original target mix changes. Overall accuracy differs too.

## Run locally

Use an existing Node.js 22 or later installation. Extract the ZIP and open
its `base-rate-queue-v1` folder in a terminal. No package installation,
account, API key, upload or network calculation is needed.

    node example.mjs
    node --test base-rate-queue.test.mjs

The example prints both complete cases as JSON, including every cell,
total and exact reduced fraction. The eight tests include independent
hand-worked values and 65,536 invented eight-item label/flag combinations.
Those small test combinations are separate from the two 10,000-item
aggregate examples. No item-level records were created for those examples.

## Inspect the receipt

- `base-rate-queue-data.json`: both complete aggregate specifications.
- `base-rate-queue.mjs`: the original calculation helper, unchanged.
- `base-rate-queue.test.mjs`: original tests adapted to these relative paths
  and one canonical fixture copy; the duplicate-site-copy check is omitted.
- `base-rate-queue.svg` and `.png`: exact original diagram files. Each bar
  means 100% of its own flagged pile, not equal absolute item counts.
- `PROVENANCE.json`: pinned source links, original hashes, adaptations and
  the existing rights context. This package adds no license or permission.
- `SHA256SUMS`: hashes of every other shipped file, excluding itself.

For example, macOS can check the manifest with `shasum -a 256 -c SHA256SUMS`
from this folder. A matching hash establishes file identity, not the truth
of an external claim.

## Scope

All counts and labels are constructed. No classifier, provider, contributor
or campaign was evaluated. The shared rates are stipulations, not evidence
that a real filter keeps its rates across populations. These descriptive
counts establish no future-item probability, threshold, staffing capacity
or future performance. A ratio with denominator zero stays null/undefined.
Displayed decimal percentages in the note are rounded; this kit keeps the
exact fractions. It is a companion to the same note, not another study.
